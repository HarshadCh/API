from django.urls import path, include
from .views import incoming_data
from rest_framework.routers import DefaultRouter
from .views import AccountViewSet, DestinationViewSet

router = DefaultRouter()
router.register('accounts', AccountViewSet)
router.register('destinations', DestinationViewSet)

urlpatterns = [
    path('', include(router.urls)),  # This includes your account/destination routes
    path('server/incoming_data', incoming_data, name='incoming_data'),  # Add your incoming_data route here
]
