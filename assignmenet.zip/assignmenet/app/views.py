from rest_framework import viewsets
from .models import Account, Destination
from .Serializers import AccountSerializer, DestinationSerializer
import requests
from django.http import JsonResponse
from rest_framework.decorators import api_view
from .models import Account


class AccountViewSet(viewsets.ModelViewSet):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer

class DestinationViewSet(viewsets.ModelViewSet):
    queryset = Destination.objects.all()
    serializer_class = DestinationSerializer

    def get_queryset(self):
        account_id = self.request.query_params.get('account_id')
        if account_id:
            return Destination.objects.filter(account__account_id=account_id)
        return super().get_queryset() 
    

@api_view(['POST'])
def incoming_data(request):
    token = request.headers.get('CL-X-TOKEN')
    if not token:
        return JsonResponse({"error": "Un Authenticate"}, status=401)

    try:
        account = Account.objects.get(app_secret_token=token)
    except Account.DoesNotExist:
        return JsonResponse({"error": "Un Authenticate"}, status=401)

    if request.content_type != 'application/json':
        return JsonResponse({"error": "Invalid Data"}, status=400)

    data = request.data
    destinations = account.destinations.all()

    for destination in destinations:
        headers = destination.headers
        method = destination.http_method
        url = destination.url
        
        if method == 'GET':
            response = requests.get(url, params=data, headers=headers)
        elif method in ['POST', 'PUT']:
            response = requests.request(method, url, json=data, headers=headers)
        else:
            continue

        if response.status_code != 200:
            return JsonResponse({"error": f"Failed to send data to {url}"}, status=500)

    return JsonResponse({"success": "Data sent successfully"})
